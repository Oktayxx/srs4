package com.example.srs_4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
