
import 'package:flutter/material.dart';

class YellowPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Yellow Page')),
      body: Container(color: Colors.yellow),
    );
  }
}